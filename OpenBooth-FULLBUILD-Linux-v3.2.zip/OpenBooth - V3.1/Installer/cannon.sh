#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
exec "$APP_DIR/bin/canon-webcam.sh" "${1:-restart}"
