const video = document.getElementById("camera")
const canvas = document.getElementById("canvas")
const ctx = canvas.getContext("2d")

const preview = document.getElementById("preview")
const finalPreview = document.getElementById("finalPreview")

const captureBtn = document.getElementById("captureBtn")
const removeBgBtn = document.getElementById("previewBtn")
const countdownDisplay = document.getElementById("countdown")

let selectedBackground = null
let selectedOverlay = null

let lastCapturedImage = null
let cutoutImage = null


// CAMERA

async function startCamera(){

try{

const stream = await navigator.mediaDevices.getUserMedia({
video:true,
audio:false
})

video.srcObject = stream

}catch(err){

alert("Camera failed")
console.error(err)

}

}

window.onload = startCamera


// BUTTON HIGHLIGHT

function highlightButton(group,id){

document.querySelectorAll(group).forEach(btn=>{
btn.classList.remove("selected")
})

document.getElementById(id).classList.add("selected")

}


// BACKGROUND SELECT

function selectBackground(n){

selectedBackground = `${n}.jpg`

highlightButton(".bgBtn","bg"+n)

}


// OVERLAY SELECT

function selectOverlay(n){

selectedOverlay = `${n}.png`

highlightButton(".overlayBtn","overlay"+n)

}


// COUNTDOWN

function startCountdown(){

if(!selectedBackground || !selectedOverlay){

alert("Select background AND overlay first")

return

}

let count = 4

countdownDisplay.innerText = count

const timer = setInterval(()=>{

count--

if(count<=0){

clearInterval(timer)

countdownDisplay.innerText=""

capturePhoto()

}else{

countdownDisplay.innerText=count

}

},1000)

}


// CAPTURE

function capturePhoto(){

canvas.width = video.videoWidth
canvas.height = video.videoHeight

ctx.drawImage(video,0,0)

const img = canvas.toDataURL("image/png")

preview.src = img

lastCapturedImage = img

}


// PROCESSING OVERLAY

function showProcessing(){

document.getElementById("processingOverlay").style.display="flex"

}

function hideProcessing(){

document.getElementById("processingOverlay").style.display="none"

}


// REMOVE BG

async function removeBackground(){

console.log("Generate preview clicked")

if(!lastCapturedImage){
    alert("Take a photo first")
    return
}

showProcessing()

try{

    console.log("Sending image to server...")

    const res = await fetch("/generate-preview",{
    method:"POST",
    headers:{
        "Content-Type":"application/json"
    },
    body:JSON.stringify({
        image: lastCapturedImage,
        background: selectedBackground,
        overlay: selectedOverlay
    })
})

const data = await res.json()

finalPreview.src = "/photos/final/" + data.file + "?t=" + Date.now()

    console.log("Server response:",data)

    cutoutImage = data.file

    composeFinal()

}catch(err){

    console.error(err)
    alert("Background removal failed")

}

hideProcessing()

}

// COMPOSE FINAL IMAGE

function composeFinal(){

if(!selectedBackground){
alert("Select a background first")
return
}

if(!selectedOverlay){
alert("Select an overlay first")
return
}

const bg = new Image()
const person = new Image()
const overlay = new Image()

bg.src = "/backgrounds/" + selectedBackground
person.src = "/photos/final/" + cutoutImage
overlay.src = "/overlay/" + selectedOverlay

Promise.all([
new Promise(r => bg.onload = r),
new Promise(r => person.onload = r),
new Promise(r => overlay.onload = r)
]).then(()=>{

canvas.width = bg.width
canvas.height = bg.height

ctx.clearRect(0,0,canvas.width,canvas.height)

/* layer 1 */
ctx.drawImage(bg,0,0,canvas.width,canvas.height)

/* layer 2 */
ctx.drawImage(person,0,0,canvas.width,canvas.height)

/* layer 3 */
ctx.drawImage(overlay,0,0,canvas.width,canvas.height)

const finalImg = canvas.toDataURL("image/png")

document.getElementById("finalPreview").src = finalImg

})
}


// SAVE

function saveImage(){

if(!finalPreview.src){

alert("Generate preview first")
return

}

const link = document.createElement("a")

link.href = finalPreview.src
link.download = "photobooth.png"

link.click()

}


// PRINT

function printImage(){

if(!finalPreview.src){

alert("Generate preview first")
return

}

const win = window.open("")

win.document.write(`<img src="${finalPreview.src}" onload="window.print();window.close()">`)

}


// KEYBINDS
// KEYBINDS
document.addEventListener("keydown",(e)=>{

if(e.code==="Space") startCountdown()

if(e.key==="1") selectBackground(1)
if(e.key==="2") selectBackground(2)
if(e.key==="3") selectBackground(3)

if(e.key==="q") selectOverlay(1)
if(e.key==="w") selectOverlay(2)

if(e.key==="r" || e.key==="R") removeBackground()

if(e.key==="s" || e.key==="S") saveImage()

})

// BUTTONS

captureBtn.onclick = startCountdown
removeBgBtn.onclick = removeBackground
document.getElementById("saveBtn").onclick = saveImage
document.getElementById("printBtn").onclick = printImage
document.getElementById("previewBtn").onclick = removeBackground