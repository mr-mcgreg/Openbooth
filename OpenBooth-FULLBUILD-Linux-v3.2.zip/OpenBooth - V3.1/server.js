const express = require("express");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { execFile } = require("child_process");
const sharp = require("sharp");
const QRCode = require("qrcode");

const app = express();
const HOST = process.env.OPENBOOTH_HOST || "0.0.0.0";
const PORT = Number(process.env.OPENBOOTH_PORT || 3000);
const ROOT = __dirname;
const publicDir = path.join(ROOT, "public");
const photosDir = path.join(ROOT, "photos");
const finalDir = path.join(photosDir, "final");
const tmpDir = path.join(photosDir, "tmp");
const rembgWrapper = path.join(ROOT, "bin", "run-rembg");

fs.mkdirSync(publicDir, { recursive: true });
fs.mkdirSync(finalDir, { recursive: true });
fs.mkdirSync(tmpDir, { recursive: true });

app.use(express.json({ limit: "80mb" }));
app.use((req, _res, next) => {
  console.log(`${new Date().toISOString()} ${req.method} ${req.url}`);
  next();
});
app.use(express.static(publicDir));
app.use("/photos", express.static(photosDir));

function writeDataUrlToFile(dataUrl, outPath) {
  const match = dataUrl.match(/^data:image\/(png|jpeg|jpg);base64,(.*)$/);
  if (!match) throw new Error("Invalid image data URL");
  fs.writeFileSync(outPath, match[2], "base64");
}

function resolveRembgCommand() {
  if (fs.existsSync(rembgWrapper)) return { cmd: rembgWrapper, argsBuilder: (input, output) => ["i", input, output] };

  const local = path.join(ROOT, ".venvs", "rembg", "bin", "rembg");
  if (fs.existsSync(local)) return { cmd: local, argsBuilder: (input, output) => ["i", input, output] };

  return { cmd: "rembg", argsBuilder: (input, output) => ["i", input, output] };
}

function getNextSequenceFilename() {
  const files = fs.readdirSync(finalDir);
  let max = 0;
  for (const f of files) {
    const m = f.match(/^(\d{4})\.png$/);
    if (m) max = Math.max(max, Number.parseInt(m[1], 10));
  }
  return `${String(max + 1).padStart(4, "0")}.png`;
}

function getBestLocalIPv4() {
  const nets = os.networkInterfaces();
  const preferredRanges = ["10.42.", "192.168.", "10.", "172."];

  for (const prefix of preferredRanges) {
    for (const ifaces of Object.values(nets)) {
      for (const iface of ifaces || []) {
        if (iface.family === "IPv4" && !iface.internal && iface.address.startsWith(prefix)) {
          return iface.address;
        }
      }
    }
  }

  for (const ifaces of Object.values(nets)) {
    for (const iface of ifaces || []) {
      if (iface.family === "IPv4" && !iface.internal) return iface.address;
    }
  }

  return "127.0.0.1";
}

let lastFinalFile = null;
const lastFilePath = path.join(photosDir, "last_final.txt");
if (fs.existsSync(lastFilePath)) {
  const saved = fs.readFileSync(lastFilePath, "utf8").trim();
  lastFinalFile = saved || null;
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, host: HOST, port: PORT, ip: getBestLocalIPv4() });
});

app.get("/network", (_req, res) => {
  res.json({ ip: getBestLocalIPv4(), port: PORT });
});

app.get("/latest", (_req, res) => {
  res.json({ file: lastFinalFile });
});

app.get("/qr", async (req, res) => {
  try {
    const text = String(req.query.text || "");
    if (!text) return res.status(400).send("Missing text");

    const svg = await QRCode.toString(text, {
      type: "svg",
      margin: 1,
      errorCorrectionLevel: "M",
    });

    res.setHeader("Content-Type", "image/svg+xml");
    res.send(svg);
  } catch (error) {
    console.error("QR error:", error);
    res.status(500).send("QR failed");
  }
});

app.post("/generate-preview", (req, res) => {
  try {
    const { image, background, overlay } = req.body;
    if (!image) return res.status(400).json({ error: "No image received" });
    if (!background) return res.status(400).json({ error: "No background selected" });
    if (!overlay) return res.status(400).json({ error: "No overlay selected" });

    const bgName = path.basename(background);
    const ovName = path.basename(overlay);
    const bgPath = path.join(publicDir, "backgrounds", bgName);
    const ovPath = path.join(publicDir, "overlay", ovName);

    if (!fs.existsSync(bgPath)) return res.status(400).json({ error: `Background not found: ${bgName}` });
    if (!fs.existsSync(ovPath)) return res.status(400).json({ error: `Overlay not found: ${ovName}` });

    const stamp = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const inputFile = path.join(tmpDir, `input_${stamp}.png`);
    const cutoutFile = path.join(tmpDir, `cutout_${stamp}.png`);
    const finalName = getNextSequenceFilename();
    const finalPath = path.join(finalDir, finalName);

    writeDataUrlToFile(image, inputFile);

    const { cmd, argsBuilder } = resolveRembgCommand();
    execFile(cmd, argsBuilder(inputFile, cutoutFile), { maxBuffer: 80 * 1024 * 1024 }, async (err, _stdout, stderr) => {
      try {
        if (err) {
          console.error("rembg error:", stderr || err);
          return res.status(500).json({ error: "Background removal failed" });
        }

        const bgMeta = await sharp(bgPath).metadata();
        const width = bgMeta.width;
        const height = bgMeta.height;
        if (!width || !height) throw new Error("Background has no width/height");

        const cutoutBuffer = await sharp(cutoutFile)
          .resize(width, height, { fit: "cover" })
          .png()
          .toBuffer();

        const overlayBuffer = await sharp(ovPath)
          .resize(width, height, { fit: "cover" })
          .png()
          .toBuffer();

        await sharp(bgPath)
          .resize(width, height, { fit: "cover" })
          .composite([
            { input: cutoutBuffer, top: 0, left: 0 },
            { input: overlayBuffer, top: 0, left: 0 },
          ])
          .png()
          .toFile(finalPath);

        lastFinalFile = finalName;
        fs.writeFileSync(lastFilePath, lastFinalFile, "utf8");

        for (const file of [inputFile, cutoutFile]) {
          try { fs.unlinkSync(file); } catch {}
        }

        return res.json({ file: finalName });
      } catch (error) {
        console.error("compose error:", error);
        return res.status(500).json({ error: "Compose failed" });
      }
    });
  } catch (error) {
    console.error("generate-preview error:", error);
    return res.status(500).json({ error: "Generate preview failed" });
  }
});

app.post("/print", (req, res) => {
  try {
    const { file } = req.body;
    if (!file) return res.status(400).json({ error: "No file provided" });

    const safe = path.basename(file);
    const filePath = path.join(finalDir, safe);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: "File not found" });

    execFile("lp", [filePath], (err, _stdout, stderr) => {
      if (err) {
        console.error("print error:", stderr || err);
        return res.status(500).json({ error: "Print failed" });
      }
      return res.json({ success: true });
    });
  } catch (error) {
    console.error("print error:", error);
    return res.status(500).json({ error: "Print failed" });
  }
});

app.get("/gallery-data", (_req, res) => {
  fs.readdir(finalDir, (err, files) => {
    if (err) return res.json([]);
    const images = files.filter((file) => file.endsWith(".png")).sort().reverse();
    res.json(images);
  });
});

app.listen(PORT, HOST, () => {
  console.log("");
  console.log("================================");
  console.log(" OpenBooth Server Running");
  console.log(` http://localhost:${PORT}`);
  console.log(` http://${getBestLocalIPv4()}:${PORT}`);
  console.log("================================");
  console.log("");
});
