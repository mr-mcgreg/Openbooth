# OpenBooth Portable Linux Edition

This package was rebuilt so it no longer depends on a specific username, home folder, or Downloads path.

## What changed

- All paths are now relative to the folder OpenBooth is extracted into.
- The installer auto-detects the package manager and installs what is missing.
- `rembg` now lives in its own isolated Python virtual environment at `.venvs/rembg`.
- Canon webcam tools are kept separate and only installed when you actually run the Canon launcher/script.
- The server is started and stopped through managed scripts with PID and log files.
- New portable `.desktop` launchers work from the extracted folder, and the installer can also copy launchers to the desktop.
- No hardcoded `/home/michael/Downloads/...` paths remain.

## Quick start

1. Extract the zip anywhere.
2. Double-click **OpenBooth Install.desktop** or run:
   ```bash
   ./install.sh
   ```
3. Launch:
   - **OpenBooth Dashboard.desktop**
   - **OpenBooth Display.desktop**
   - **OpenBooth Gallery.desktop**

## Main scripts

- `bin/bootstrap.sh` — install/check dependencies and create launchers
- `bin/manage.sh start|stop|restart|status|logs` — manage the Node server
- `bin/open-ui.sh` — start server and open dashboard
- `bin/open-display.sh` — start server and open display page
- `bin/open-gallery.sh` — start server and open gallery page
- `bin/hotspot.sh start|stop|status` — manage hotspot through NetworkManager
- `bin/canon-webcam.sh start|stop|restart|status` — isolated Canon webcam helper

## Canon isolation

Canon mode is not required for the booth to work.

Nothing Canon-specific is installed during the normal app bootstrap except shared base packages. Canon webcam support is only checked and installed the first time you run:

```bash
./bin/canon-webcam.sh start
```

## Logs and runtime files

- Server log: `logs/server.log`
- Canon log: `logs/canon.log`
- PID files: `.runtime/`

## Notes

- Hotspot mode needs a Wi-Fi adapter that supports AP mode.
- Printing needs CUPS available on the system.
- Some desktops require you to mark `.desktop` files as trusted/executable after extracting.
