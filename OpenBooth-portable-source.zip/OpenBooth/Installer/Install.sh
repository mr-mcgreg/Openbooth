#!/usr/bin/env bash
# //Purpose: Install and configure everything needed to run OpenBooth on an apt-based Linux computer.
set -euo pipefail

# //Purpose: OpenBooth full installer/setup.
# //Purpose: Usage:
# //Purpose:   cd /path/to/OpenBooth
# //Purpose:   chmod +x INSTALL_ALL.sh
# //Purpose:   ./INSTALL_ALL.sh
#
# //Purpose: What it does:
# //Purpose: - Installs system packages (node, npm, python, build tools, firefox)
# //Purpose: - Creates python venv and installs rembg + deps
# //Purpose: - Installs node deps (npm install)
# //Purpose: - Writes a small wrapper to run rembg reliably
# //Purpose: - Optionally creates/updates NetworkManager hotspot connection "OpenBooth" (open, no password)
# //Purpose: - Creates Desktop launchers for dashboard + display
#
# //Purpose: Notes:
# //Purpose: - WiFi hotspot requires a WiFi adapter that supports AP mode
# //Purpose: - Some systems may require you to run hotspot commands with sudo
# //Purpose: - iPhones may warn "No Internet"; that's normal for offline booths

# //Purpose: Find the OpenBooth app folder even when this script lives inside Installer/.
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$APP_DIR"

echo ""
echo "========================================"
echo " OpenBooth INSTALLER"
echo " APP_DIR: $APP_DIR"
echo "========================================"
echo ""

# //Purpose: Stop if this computer does not use apt-get package management.
if ! command -v apt-get >/dev/null 2>&1; then
  echo "ERROR: This installer currently supports apt-based distros (Ubuntu/Debian/Mint)."
  echo "Tell me your distro and I’ll convert it (Fedora/Arch/etc.)."
  exit 1
fi

# //Purpose: Decide whether commands should run directly as root or through sudo.
if [[ $EUID -ne 0 ]]; then
  if ! command -v sudo >/dev/null 2>&1; then
    echo "ERROR: sudo not found. Run this as root."
    exit 1
  fi
  SUDO="sudo"
else
  SUDO=""
fi

# //Purpose: Install Linux packages needed for the booth, image processing, and browser display.
echo "[1/7] Installing system packages..."
$SUDO apt-get update -y
$SUDO apt-get install -y \
  curl ca-certificates gnupg \
  python3 python3-venv python3-pip \
  build-essential \
  firefox \
  imagemagick \
  git

# //Purpose: Install Node.js and npm from the distro packages.
echo "[2/7] Installing Node.js + npm..."
$SUDO apt-get install -y nodejs npm

# //Purpose: Show installed Node and npm versions for troubleshooting.
echo "Node: $(node -v || true)"
echo "NPM:  $(npm -v || true)"

# //Purpose: Create the Python virtual environment used by rembg.
echo "[3/7] Setting up Python venv + rembg..."
VENV_DIR="$APP_DIR/.venv"
if [[ ! -d "$VENV_DIR" ]]; then
  python3 -m venv "$VENV_DIR"
fi

# //Purpose: Activate the local Python environment for package installation.
# shellcheck disable=SC1091
source "$VENV_DIR/bin/activate"

# //Purpose: Update Python packaging tools inside the virtual environment.
python -m pip install --upgrade pip wheel setuptools

# //Purpose: Install rembg and its image-processing dependencies explicitly.
# //Purpose: These packages avoid common "module not found" errors.
python -m pip install --upgrade \
  rembg \
  onnxruntime \
  filetype \
  pillow \
  numpy \
  pymatting \
  scikit-image

# //Purpose: Create a wrapper so Node can call rembg reliably regardless of PATH.
echo "[4/7] Creating rembg wrapper..."
BIN_DIR="$APP_DIR/bin"
mkdir -p "$BIN_DIR"

cat > "$BIN_DIR/rembg_run.sh" <<'EOF'
#!/usr/bin/env bash
# //Purpose: Run rembg from the OpenBooth Python virtual environment.
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
source "$APP_DIR/.venv/bin/activate"
exec rembg "$@"
EOF
chmod +x "$BIN_DIR/rembg_run.sh"

# //Purpose: Install JavaScript dependencies used by the OpenBooth server.
echo "[5/7] Installing Node dependencies..."
if [[ ! -f "$APP_DIR/package.json" ]]; then
  echo "No package.json found. Creating one..."
  npm init -y >/dev/null
fi

# //Purpose: Install required Node packages; this is safe to re-run.
npm install express sharp qrcode

# //Purpose: Create the photo and asset folders expected by the app.
echo "[6/7] Ensuring folders exist..."
mkdir -p "$APP_DIR/photos/final" "$APP_DIR/photos/tmp" "$APP_DIR/public/backgrounds" "$APP_DIR/public/overlay"

# //Purpose: Configure the OpenBooth Wi-Fi hotspot connection in NetworkManager.
echo "[7/7] Checking optional NetworkManager hotspot setup..."

if [[ "${SETUP_HOTSPOT:-0}" != "1" ]]; then
  echo "Hotspot setup skipped."
  echo "To enable it later, run: SETUP_HOTSPOT=1 ./Installer/Install.sh"
else
  $SUDO apt-get install -y network-manager

# //Purpose: Detect the first Wi-Fi interface available on the computer.
WIFI_IFACE="$(nmcli -t -f DEVICE,TYPE dev status | awk -F: '$2=="wifi"{print $1; exit}')"
if [[ -z "${WIFI_IFACE:-}" ]]; then
  echo "WARNING: No WiFi interface detected. Hotspot setup skipped."
  echo "You can run the booth without hotspot, or plug in a WiFi adapter."
else
  echo "WiFi interface detected: $WIFI_IFACE"

  # //Purpose: Delete any existing OpenBooth connection to avoid mixed security settings.
  nmcli con delete OpenBooth >/dev/null 2>&1 || true

  # //Purpose: Create an open access-point connection named OpenBooth.
  nmcli con add type wifi ifname "$WIFI_IFACE" con-name OpenBooth ssid OpenBooth \
    802-11-wireless.mode ap ipv4.method shared >/dev/null

  # //Purpose: Remove Wi-Fi security settings so guests can join without a password.
  nmcli con modify OpenBooth -802-11-wireless-security >/dev/null 2>&1 || true

  echo "Hotspot connection 'OpenBooth' created."
  echo "Start hotspot: nmcli con up OpenBooth"
  echo "Stop hotspot:  nmcli con down OpenBooth"
fi
fi

# //Purpose: Create desktop launchers when the user's Desktop folder exists.
DESKTOP_DIR="$HOME/Desktop"
if [[ -d "$DESKTOP_DIR" ]]; then
  echo "Creating Desktop launchers..."

  # //Purpose: Create a launcher that starts the dashboard server from this installed folder.
  cat > "$DESKTOP_DIR/OpenBooth-Dashboard.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=OpenBooth Dashboard
Comment=OpenBooth dashboard UI
Icon=utilities-terminal
Terminal=true
Categories=Utility;
Exec=sh -c "cd \"$APP_DIR\"; echo \"Starting OpenBooth...\"; npm start"
EOF
  chmod +x "$DESKTOP_DIR/OpenBooth-Dashboard.desktop"

  # //Purpose: Create a launcher that starts the server and opens the display page in Firefox.
  cat > "$DESKTOP_DIR/OpenBooth-Display.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=OpenBooth Display
Comment=OpenBooth display screen
Icon=utilities-terminal
Terminal=true
Categories=Utility;
Exec=sh -c "cd \"$APP_DIR\"; echo \"Starting OpenBooth...\"; npm start & sleep 1; firefox --new-window http://localhost:3000/display.html; wait"
EOF
  chmod +x "$DESKTOP_DIR/OpenBooth-Display.desktop"

  echo "Desktop launchers created on: $DESKTOP_DIR"
else
  echo "Desktop folder not found; skipping .desktop launchers."
fi

# //Purpose: Leave the Python virtual environment before finishing.
deactivate || true

echo ""
echo "========================================"
echo " INSTALL COMPLETE"
echo "========================================"
echo ""
echo "NEXT STEPS:"
echo "  1) Start server:              cd \"$APP_DIR\" && npm start"
echo "  2) Open dashboard:            http://localhost:3000/"
echo "  3) Open display:              http://localhost:3000/display.html"
echo ""
echo "Hotspot start/stop:"
echo "  Setup: SETUP_HOTSPOT=1 ./Installer/Install.sh"
echo "  Start: nmcli con up OpenBooth"
echo "  Stop:  nmcli con down OpenBooth"
echo ""
echo "IMPORTANT:"
echo "  - Some WiFi cards cannot create hotspots (no AP mode)."
echo "  - iPhones may warn 'No Internet'. That’s normal for offline booths."
echo ""
echo "If rembg is slow or fails, we can switch to GPU or tune models."
echo ""
