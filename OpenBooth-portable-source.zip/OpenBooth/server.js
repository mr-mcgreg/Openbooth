//Purpose: Load the Node libraries used by the photobooth server.
const express = require("express");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { exec } = require("child_process");
const sharp = require("sharp");
const QRCode = require("qrcode");

//Purpose: Create the web server and choose the port it will listen on.
const app = express();
const PORT = Number(process.env.PORT || 3000);

//Purpose: Define the main folders used for web files, saved photos, and temporary processing files.
const publicDir = path.join(__dirname, "public");
const photosDir = path.join(__dirname, "photos");
const finalDir = path.join(photosDir, "final");
const tmpDir = path.join(photosDir, "tmp");
const projectRembgWrapper = path.join(__dirname, "bin", "rembg_run.sh");
const projectRembgVenv = path.join(__dirname, ".venv", "bin", "rembg");

//Purpose: Make sure required folders exist before the server starts handling photos.
fs.mkdirSync(publicDir, { recursive: true });
fs.mkdirSync(finalDir, { recursive: true });
fs.mkdirSync(tmpDir, { recursive: true });

//Purpose: Allow large JSON uploads because camera photos are sent as base64 image data.
app.use(express.json({ limit: "80mb" }));

//Purpose: Print each browser request so server activity is easy to debug.
app.use((req, _res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

//Purpose: Serve the dashboard pages, CSS, JavaScript, backgrounds, and overlays from public/.
app.use(express.static(publicDir));

//Purpose: Make generated photos available in the browser under /photos.
app.use("/photos", express.static(photosDir));

/* -------------------- Helpers -------------------- */

//Purpose: Convert a browser data URL image into a real image file on disk.
function writeDataUrlToFile(dataUrl, outPath) {
  const m = dataUrl.match(/^data:image\/(png|jpeg|jpg);base64,(.*)$/);
  if (!m) throw new Error("Invalid image data URL");
  fs.writeFileSync(outPath, m[2], "base64");
}

//Purpose: Find the rembg command used to remove the photo background.
function getRembgCmd() {
  //Purpose: Let advanced users provide a custom rembg command without editing this file.
  if (process.env.REMBG_CMD) return process.env.REMBG_CMD;

  //Purpose: Prefer the rembg wrapper created inside this OpenBooth folder by the installer.
  if (fs.existsSync(projectRembgWrapper)) return `"${projectRembgWrapper}"`;

  //Purpose: Use the project virtual environment directly if the wrapper is missing.
  if (fs.existsSync(projectRembgVenv)) return `"${projectRembgVenv}"`;

  //Purpose: Fall back to a user-local rembg install when it exists.
  const localRembg = path.join(os.homedir(), ".local", "bin", "rembg");
  if (fs.existsSync(localRembg)) return `"${localRembg}"`;

  //Purpose: Last fallback is the system PATH, which works if rembg was installed globally.
  return "rembg";
}

//Purpose: Pick the next numbered filename for a finished photo, such as 0001.png.
function getNextSequenceFilename() {
  const files = fs.readdirSync(finalDir);
  let max = 0;

  //Purpose: Scan existing final photos and remember the highest number already used.
  for (const f of files) {
    const m = f.match(/^(\d{4})\.png$/);
    if (m) {
      const n = parseInt(m[1], 10);
      if (n > max) max = n;
    }
  }

  const next = max + 1;
  return String(next).padStart(4, "0") + ".png";
}

//Purpose: Find the booth network IP so phones can scan a QR code and reach the photo server.
function getHotspotIP() {
  //Purpose: Let another computer choose the displayed host/IP without editing code.
  if (process.env.BOOTH_HOST) return process.env.BOOTH_HOST;

  //Purpose: Look through network adapters for common private or hotspot IP ranges.
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const iface of nets[name]) {
      if (iface.family === "IPv4" && !iface.internal) {
        const ip = iface.address;
        if (
          ip.startsWith("10.42.") ||
          ip.startsWith("192.168.") ||
          ip.startsWith("172.16.") ||
          ip.startsWith("172.17.") ||
          ip.startsWith("172.18.") ||
          ip.startsWith("172.19.") ||
          ip.startsWith("172.2") ||  // covers 172.20-172.29
          ip.startsWith("172.3")     // covers 172.30-172.31
        ) {
          return ip;
        }
      }
    }
  }
  //Purpose: Fall back to localhost when no shared network address is available.
  return "127.0.0.1";
}

/* -------------------- State -------------------- */

//Purpose: Remember the most recent finished photo so display screens can show it.
let lastFinalFile = null;
const lastFilePath = path.join(photosDir, "last_final.txt");
if (fs.existsSync(lastFilePath)) {
  const t = fs.readFileSync(lastFilePath, "utf8").trim();
  lastFinalFile = t || null;
}

/* -------------------- Routes -------------------- */

//Purpose: Send the current booth network address to the display page.
app.get("/network", (_req, res) => {
  res.json({ ip: getHotspotIP(), port: PORT });
});

//Purpose: Tell display and gallery pages which final photo was generated most recently.
app.get("/latest", (_req, res) => {
  res.json({ file: lastFinalFile });
});

//Purpose: Generate a QR code image for a given photo URL without needing the internet.
app.get("/qr", async (req, res) => {
  try {
    const text = req.query.text || "";
    if (!text) return res.status(400).send("Missing text");

    const svg = await QRCode.toString(text, {
      type: "svg",
      margin: 1,
      errorCorrectionLevel: "M",
    });

    res.setHeader("Content-Type", "image/svg+xml");
    res.send(svg);
  } catch (e) {
    console.error("QR error:", e);
    res.status(500).send("QR failed");
  }
});

//Purpose: Main photo pipeline: receive a captured image, remove the background, composite it, and save it.
//Purpose: Expected request body is { image: dataURL, background: "1.jpg", overlay: "1.png" }.
app.post("/generate-preview", (req, res) => {
  try {
    //Purpose: Read the captured photo and selected design assets from the browser request.
    const { image, background, overlay } = req.body;

    //Purpose: Stop early if the browser did not send everything needed to build the final image.
    if (!image) return res.status(400).json({ error: "No image received" });
    if (!background) return res.status(400).json({ error: "No background selected" });
    if (!overlay) return res.status(400).json({ error: "No overlay selected" });

    //Purpose: Keep asset names safe so requests cannot escape the backgrounds or overlay folders.
    const bgName = path.basename(background);
    const ovName = path.basename(overlay);

    //Purpose: Build the full paths to the selected background and overlay files.
    const bgPath = path.join(publicDir, "backgrounds", bgName);
    const ovPath = path.join(publicDir, "overlay", ovName);

    //Purpose: Confirm the selected asset files actually exist before processing.
    if (!fs.existsSync(bgPath)) {
      return res.status(400).json({ error: `Background not found: ${bgName}` });
    }
    if (!fs.existsSync(ovPath)) {
      return res.status(400).json({ error: `Overlay not found: ${ovName}` });
    }

    //Purpose: Create unique temporary filenames for this photo job.
    const stamp = Date.now();
    const inputFile = path.join(tmpDir, `input_${stamp}.png`);
    const cutoutFile = path.join(tmpDir, `cutout_${stamp}.png`);

    //Purpose: Reserve the next final photo filename, such as 0001.png.
    const finalName = getNextSequenceFilename();
    const finalPath = path.join(finalDir, finalName);

    //Purpose: Save the uploaded browser image so rembg can process it as a file.
    writeDataUrlToFile(image, inputFile);

    //Purpose: Run rembg to cut the person out from the captured image.
    const cmd = `${getRembgCmd()} i "${inputFile}" "${cutoutFile}"`;
    exec(cmd, { maxBuffer: 80 * 1024 * 1024 }, async (err, _stdout, stderr) => {
      try {
        //Purpose: Return an error if background removal fails.
        if (err) {
          console.error("rembg error:", stderr || err);
          return res.status(500).json({ error: "Background removal failed" });
        }

        //Purpose: Use the background size as the master size for the final image.
const bgMeta = await sharp(bgPath).metadata();
const W = bgMeta.width;
const H = bgMeta.height;

//Purpose: Stop if Sharp cannot read the background dimensions.
if (!W || !H) {
  throw new Error("Background has no width/height");
}

//Purpose: Resize the person cutout to match the background exactly.
const cutoutBuf = await sharp(cutoutFile)
  .resize(W, H, { fit: "cover" })
  .png()
  .toBuffer();

//Purpose: Resize the decorative overlay to match the background exactly.
const overlayBuf = await sharp(ovPath)
  .resize(W, H, { fit: "cover" })
  .png()
  .toBuffer();

//Purpose: Build the final photo in layers: background, person cutout, then overlay.
await sharp(bgPath)
  .resize(W, H, { fit: "cover" })
  .composite([
    { input: cutoutBuf, top: 0, left: 0 },
    { input: overlayBuf, top: 0, left: 0 },
  ])
  .png()
  .toFile(finalPath);

        //Purpose: Update the latest-photo pointer for the display screen and gallery.
        lastFinalFile = finalName;
        try {
          fs.writeFileSync(lastFilePath, lastFinalFile, "utf8");
        } catch (_) {}

        //Purpose: Delete temporary files after the final image has been saved.
        try { fs.unlinkSync(inputFile); } catch (_) {}
        try { fs.unlinkSync(cutoutFile); } catch (_) {}

        //Purpose: Tell the browser which final photo file was created.
        return res.json({ file: finalName });
      } catch (e) {
        console.error("compose error:", e);
        return res.status(500).json({ error: "Compose failed" });
      }
    });
  } catch (e) {
    console.error("generate-preview error:", e);
    return res.status(500).json({ error: "Generate preview failed" });
  }
});

//Purpose: Print one finished photo through the Linux lp print command.
app.post("/print", (req, res) => {
  try {
    //Purpose: Read and validate the requested final photo filename.
    const { file } = req.body;
    if (!file) return res.status(400).json({ error: "No file provided" });

    const safe = path.basename(file);
    const filePath = path.join(finalDir, safe);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: "File not found" });
    }

    //Purpose: Send the selected photo to the system printer.
    exec(`lp "${filePath}"`, (err, _stdout, stderr) => {
      if (err) {
        console.error("print error:", stderr || err);
        return res.status(500).json({ error: "Print failed" });
      }
      return res.json({ success: true });
    });
  } catch (e) {
    console.error("print error:", e);
    return res.status(500).json({ error: "Print failed" });
  }
});

//Purpose: Send the gallery page a newest-first list of finished photo filenames.
app.get("/gallery-data", (req, res) => {

  //Purpose: Read final photos from the folder where completed booth images are stored.
  const dir = path.join(__dirname,"photos","final")

  fs.readdir(dir,(err,files)=>{

    //Purpose: Return an empty gallery if the folder cannot be read.
    if(err) return res.json([])

    //Purpose: Keep only PNG files and show the newest numbered photos first.
    const images = files
      .filter(f=>f.endsWith(".png"))
      .sort()
      .reverse()

    res.json(images)

  })

})

/* -------------------- Start -------------------- */

//Purpose: Start the booth web server so browsers can open the dashboard, display, and gallery.
app.listen(PORT, "0.0.0.0", () => {
  console.log("");
  console.log("================================");
  console.log(" OpenBooth Server Running");
  console.log(` http://localhost:${PORT}`);
  console.log("================================");
  console.log("");
});
