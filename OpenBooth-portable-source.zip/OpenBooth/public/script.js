//Purpose: Find the hidden camera video and canvas used for capturing photos.
const video = document.getElementById("camera")
const canvas = document.getElementById("canvas")
const ctx = canvas.getContext("2d")

//Purpose: Find the preview image elements shown on the dashboard.
const preview = document.getElementById("preview")
const finalPreview = document.getElementById("finalPreview")

//Purpose: Find the main control buttons and countdown display.
const captureBtn = document.getElementById("captureBtn")
const removeBgBtn = document.getElementById("previewBtn")
const countdownDisplay = document.getElementById("countdown")

//Purpose: Store which background and overlay the operator selected.
let selectedBackground = null
let selectedOverlay = null

//Purpose: Store the captured photo and final generated file while the booth is running.
let lastCapturedImage = null
let cutoutImage = null


//Purpose: CAMERA

//Purpose: Ask the browser for webcam access and stream it into the video element.
async function startCamera(){

try{

//Purpose: Request video only because the booth does not need microphone audio.
const stream = await navigator.mediaDevices.getUserMedia({
video:true,
audio:false
})

//Purpose: Show the live camera stream on the dashboard.
video.srcObject = stream

}catch(err){

//Purpose: Warn the operator if the browser cannot open the camera.
alert("Camera failed")
console.error(err)

}

}

//Purpose: Start the camera automatically when the page finishes loading.
window.onload = startCamera


//Purpose: BUTTON HIGHLIGHT

//Purpose: Visually mark the selected button in a group and clear the previous selection.
function highlightButton(group,id){

document.querySelectorAll(group).forEach(btn=>{
btn.classList.remove("selected")
})

document.getElementById(id).classList.add("selected")

}


//Purpose: BACKGROUND SELECT

//Purpose: Save the chosen background filename and highlight its button.
function selectBackground(n){

selectedBackground = `${n}.jpg`

highlightButton(".bgBtn","bg"+n)

}


//Purpose: OVERLAY SELECT

//Purpose: Save the chosen overlay filename and highlight its button.
function selectOverlay(n){

selectedOverlay = `${n}.png`

highlightButton(".overlayBtn","overlay"+n)

}


//Purpose: COUNTDOWN

//Purpose: Run the countdown before taking a photo.
function startCountdown(){

//Purpose: Require the operator to choose both design layers before capture.
if(!selectedBackground || !selectedOverlay){

alert("Select background AND overlay first")

return

}

//Purpose: Begin at 4 and update the large on-screen countdown once per second.
let count = 4

countdownDisplay.innerText = count

const timer = setInterval(()=>{

count--

//Purpose: Capture the photo when the countdown reaches zero.
if(count<=0){

clearInterval(timer)

countdownDisplay.innerText=""

capturePhoto()

}else{

countdownDisplay.innerText=count

}

},1000)

}


//Purpose: CAPTURE

//Purpose: Copy the current video frame into the canvas and save it as a PNG data URL.
function capturePhoto(){

//Purpose: Match the canvas size to the camera feed so the capture keeps its full resolution.
canvas.width = video.videoWidth
canvas.height = video.videoHeight

//Purpose: Draw the live camera frame onto the canvas.
ctx.drawImage(video,0,0)

const img = canvas.toDataURL("image/png")

//Purpose: Show the raw captured photo and keep it ready for server processing.
preview.src = img

lastCapturedImage = img

}


//Purpose: PROCESSING OVERLAY

//Purpose: Show the full-screen processing message while the server builds the final image.
function showProcessing(){

document.getElementById("processingOverlay").style.display="flex"

}

//Purpose: Hide the processing message after the server responds.
function hideProcessing(){

document.getElementById("processingOverlay").style.display="none"

}


//Purpose: REMOVE BG

//Purpose: Send the captured photo to the server for background removal and compositing.
async function removeBackground(){

console.log("Generate preview clicked")

//Purpose: Require a captured image before trying to generate the final preview.
if(!lastCapturedImage){
    alert("Take a photo first")
    return
}

showProcessing()

try{

    console.log("Sending image to server...")

    //Purpose: Upload the captured photo plus selected background and overlay to the server.
    const res = await fetch("/generate-preview",{
    method:"POST",
    headers:{
        "Content-Type":"application/json"
    },
    body:JSON.stringify({
        image: lastCapturedImage,
        background: selectedBackground,
        overlay: selectedOverlay
    })
})

const data = await res.json()

//Purpose: Show the saved final server image and add a timestamp to avoid browser caching.
finalPreview.src = "/photos/final/" + data.file + "?t=" + Date.now()

    console.log("Server response:",data)

    //Purpose: Remember the generated file so the local canvas preview can load it.
    cutoutImage = data.file

    composeFinal()

}catch(err){

    //Purpose: Warn the operator if the server could not generate the photo.
    console.error(err)
    alert("Background removal failed")

}

//Purpose: Remove the processing overlay after success or failure.
hideProcessing()

}

//Purpose: COMPOSE FINAL IMAGE

//Purpose: Rebuild the visible final preview in the browser from the selected layers.
function composeFinal(){

//Purpose: Require a background before browser-side composition.
if(!selectedBackground){
alert("Select a background first")
return
}

//Purpose: Require an overlay before browser-side composition.
if(!selectedOverlay){
alert("Select an overlay first")
return
}

//Purpose: Create image objects for the background, processed person, and overlay.
const bg = new Image()
const person = new Image()
const overlay = new Image()

//Purpose: Point each image object at its matching asset or generated final photo.
bg.src = "/backgrounds/" + selectedBackground
person.src = "/photos/final/" + cutoutImage
overlay.src = "/overlay/" + selectedOverlay

//Purpose: Wait until all three images are loaded before drawing them on the canvas.
Promise.all([
new Promise(r => bg.onload = r),
new Promise(r => person.onload = r),
new Promise(r => overlay.onload = r)
]).then(()=>{

canvas.width = bg.width
canvas.height = bg.height

//Purpose: Clear old canvas pixels before drawing the new final preview.
ctx.clearRect(0,0,canvas.width,canvas.height)

/* //Purpose: Draw layer 1, the selected background. */
ctx.drawImage(bg,0,0,canvas.width,canvas.height)

/* //Purpose: Draw layer 2, the generated person photo. */
ctx.drawImage(person,0,0,canvas.width,canvas.height)

/* //Purpose: Draw layer 3, the selected decorative overlay. */
ctx.drawImage(overlay,0,0,canvas.width,canvas.height)

//Purpose: Convert the layered canvas into a PNG image for the final preview.
const finalImg = canvas.toDataURL("image/png")

document.getElementById("finalPreview").src = finalImg

})
}


//Purpose: SAVE

//Purpose: Download the currently visible final preview image from the dashboard.
function saveImage(){

//Purpose: Require a generated preview before saving.
if(!finalPreview.src){

alert("Generate preview first")
return

}

//Purpose: Create a temporary download link for the final image.
const link = document.createElement("a")

link.href = finalPreview.src
link.download = "photobooth.png"

link.click()

}


//Purpose: PRINT

//Purpose: Open the final preview in a print window and start browser printing.
function printImage(){

//Purpose: Require a generated preview before printing.
if(!finalPreview.src){

alert("Generate preview first")
return

}

//Purpose: Create a temporary print window containing only the final image.
const win = window.open("")

win.document.write(`<img src="${finalPreview.src}" onload="window.print();window.close()">`)

}


//Purpose: KEYBINDS

//Purpose: Map keyboard shortcuts to the main photobooth actions.
document.addEventListener("keydown",(e)=>{

if(e.code==="Space") startCountdown()

if(e.key==="1") selectBackground(1)
if(e.key==="2") selectBackground(2)
if(e.key==="3") selectBackground(3)

if(e.key==="q") selectOverlay(1)
if(e.key==="w") selectOverlay(2)

if(e.key==="r" || e.key==="R") removeBackground()

if(e.key==="s" || e.key==="S") saveImage()

})

//Purpose: BUTTONS

//Purpose: Connect dashboard button clicks to the same functions used by keyboard shortcuts.
captureBtn.onclick = startCountdown
removeBgBtn.onclick = removeBackground
document.getElementById("saveBtn").onclick = saveImage
document.getElementById("printBtn").onclick = printImage
document.getElementById("previewBtn").onclick = removeBackground
